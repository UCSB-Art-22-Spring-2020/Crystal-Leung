var x0,y1, x1,y1; 
var stepSizeX, stepSizeY; 

function setup() {
  createCanvas(600, 600);
  background(193,98,108); 
  
  x0= x1= width/2; 
  y0= y1= height/2; 
  stepSizeX= 7 ; //everytime draw loop goes, we move 3 pixels 
  stepSizeY= 7;
}

function draw() {
  strokeWeight (10); //size of point
  stroke (255,100); //color of point
  point(x0, y0); //draw point 

  x0 = x0 + random(-stepSizeX, stepSizeX); 
  y0 = y0+ random(-stepSizeY, stepSizeY); 

  if (x0 > width || x0< 0) { //reset location if we go off the screen 
    x0= random(0, width);
  } 
  if (y0 > height || y0< 0) { //reset location if we go off the screen 
    y0= random(0, height);
  }

  //draw point 1 
  strokeWeight (10); //size of point
  stroke (246,239,217,100); //color of point
  point(x1, y1); //draw point 

  x1 = x1 + random(-stepSizeY, stepSizeY); 
  y1 = y1+ random(-stepSizeX, stepSizeX); 

  if (x1 > width || x1< 0) { //reset location if we go off the screen 
    x0= random(0, width);
  } 
  if (y1 > height || y1< 0) { //reset location if we go off the screen 
    y0= random(0, height);
  }

}